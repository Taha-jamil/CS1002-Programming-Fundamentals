#include<stdio.h>
int checkbox(char a ,char b);      //Function declaration  

int main(void)
{
    //Take input from the user
    char box_1,box_2;
    printf("Enter the color of the first box ('r' for Red) ('g' for geen) ('b' for blue) : \n");
    scanf(" %c",&box_1);
     printf("Enter the color of the second box ('r' for Red) ('g' for geen) ('b' for blue) : \n");
    scanf(" %c",&box_2);
   
   //use conditional statemenrs
    if (box_1 == 98)
    {
     printf("\n");
   }
    else if(box_1 == 103)
     {
     printf("\n");
    ;}
    else if (box_1 == 114)
     {
     printf("\n");
     }
   else if (box_2 == 98)
    {
    printf("\n");
    }
   else if (box_2 == 103) 
    {
    printf("\n");
    }
   else if (box_2 == 114)
    {
    printf("\n");

}
   else{
   printf("Invalid input");
   return 0;
   }
    //Function Calling
    checkbox(box_1,box_2);

    return 0;
      
}
int checkbox(char a ,char b)         //function defination
{
     if(a==b)
    {
        
        printf("Invalid Placement");
        return -1;
        
    }
    else{
        printf("Valid Statement");
        return 1;
    }
    
}
