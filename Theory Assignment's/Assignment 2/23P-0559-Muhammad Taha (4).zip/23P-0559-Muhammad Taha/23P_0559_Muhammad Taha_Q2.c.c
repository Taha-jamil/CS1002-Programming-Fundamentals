#include<stdio.h>
int formulaOne(int a,int b);  //Function declaration
int formulaTwo(int c);        //Function declaration
float get_value_car1();       //Function declaration
float get_value_car2();       //Function declaration
float get_value_car1(void){
    int power,speed,efficency;//local declaration
    printf("Enter power of the car 1 Engine : ");
    scanf("%d",&power);//taking power as input
    printf("Enter speed of the car 1  : ");
    scanf("%d",&speed);//taking speed as input
    float total_power_output = formulaOne(power,speed);/*assigning value of function to 
    variable*/
    
    printf("Enter the efficiency of Car1 engine : ");
    scanf("%d",&efficency);//taking efficiency as input
   int engine_efficiency_at_high_speeds = formulaTwo(efficency);
    return total_power_output + engine_efficiency_at_high_speeds;
}
    
    float get_value_car2(void)//user define function
    {
    int power,speed,efficency;//local declaration
    printf("Enter power of the car 2 Engine : ");
    scanf("%d",&power);
    printf("Enter speed of the car 2 : ");
    scanf("%d",&speed);
    float total_power_output=formulaOne(power,speed);
    
    printf("Enter the efficiency of Car2 engine : ");
    scanf("%d",&efficency);
   int engine_efficiency_at_high_speeds = formulaTwo(efficency);
    return total_power_output + engine_efficiency_at_high_speeds;
}
int formulaOne(int a,int b)//user define function with 2 perameters
{
    return a+b;	}
    int formulaTwo(int c)//user define function with 1 parameter
    {
    return c*c;
}
int main(void)
{
float efficencyof1stcar=get_value_car1();//function calling
float efficencyof2ndcar=get_value_car2();//function calling
printf("The efficency is %.2f",efficencyof1stcar + efficencyof2ndcar);

return 0;

}
