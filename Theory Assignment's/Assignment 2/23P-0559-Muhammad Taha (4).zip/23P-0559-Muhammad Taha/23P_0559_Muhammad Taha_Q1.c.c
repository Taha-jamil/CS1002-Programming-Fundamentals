#include<stdio.h>
#define spaceshipcost 20.00;                //Macro/define constant
#define Costofspaceshipperunitdistance 10.00;
#define portalcost  500.00;

float calPortal(int portal_count);        //Functions Declarations
float calSpaceship(int spaceship_count, int distance);
float calTotal(int portalCost,int spaceShipcost);
int main(void)
{
    int spaceship_count,portal_count,distance;
      printf("Enter the Portal count \n");        //Take inout from the user
    scanf("%d",&portal_count);
    printf("Enter the spaceship count \n");
    scanf("%d",&spaceship_count);
     
       printf("Enter the distance which you want to travel in units  ");
    scanf("%d",&distance);
    float portalCost = calPortal(portal_count);    //Functions Call
    float spaceShipcost = calSpaceship(spaceship_count, distance);   //Functions Call
   float Total = calTotal(portalCost ,spaceShipcost);    //Functions Call
   printf("The cost of Portal is : %.2f\n",portalCost);
   printf("The cost of  SpaceShip is  : %.2f\n",spaceShipcost);
   printf("The Total Cost of Portal and Space Ship is : %.2f\n",Total);
   
    return 0;
}
 float calPortal(int portal_count)  //Function Defination
{
    return portal_count*portalcost;
}
float calSpaceship(int spaceship_count, int distance)  //Function Defination
{
    return spaceship_count*spaceshipcost+distance*Costofspaceshipperunitdistance;
}
float calTotal(int portalCost,int spaceShipcost)    //Function Defination
{
    return portalCost+spaceShipcost;
}

