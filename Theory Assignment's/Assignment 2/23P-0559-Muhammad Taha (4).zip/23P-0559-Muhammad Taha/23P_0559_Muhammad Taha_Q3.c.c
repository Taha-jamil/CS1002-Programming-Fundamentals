#include<stdio.h>
float check(float revenue, float expenses); //Function declaration
int main(void)

{
float revenue,expenses;            //Take revenue and expenses from the user as a input
printf("Enter the total revenue : ");
scanf("%f",&revenue);
printf("Enter the total expenses : ");
scanf("%f",&expenses);

check(revenue,expenses); //Function calling

return 0;

}
//function defination 
float check(float revenue, float expenses){
float netprofit,profitmargin,returnoninvestment;  

 netprofit=revenue - expenses;             //Formulae for Calculation
profitmargin = netprofit / revenue;
returnoninvestment=netprofit / expenses;

if(revenue==0)           //use conditionals Statements to make code more efficient
{
  printf("Informative error (revenue can't be equal to zero)");
   return -1;
}
if(expenses==0)
{
  printf("Informative error (expenses can't be equal to zero)");
   return -1;
}
if(expenses>revenue)
{
  printf("Informative error (expenses can't be greater than revenue)");
   return 1;
}
if(profitmargin<0)
{
  printf("Informative error (profitmargin can't be less than zero)");
   return 1;
}
if(returnoninvestment<0)
{
  printf("Informative error (return on investment can't be less than zero)");
   return 1;
}
                                   //output 

printf("The total revenue for the year is : $%.2f\n",revenue);
printf("The total expenses for the year is  : $%.2f\n",expenses);
printf("The net profit for the year is : $%.2f\n",netprofit);
printf("The profit margin for the year is : $%.2f\n",profitmargin);
printf("The return on investment for the year : $%.2f\n",returnoninvestment);


}
